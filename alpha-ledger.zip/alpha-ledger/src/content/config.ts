import { defineCollection, z } from 'astro:content';

// Schema for every article in src/content/posts/*.md
// Adding an article means: drop a new .md file here with this front matter
// filled in. Nothing else needs to be touched — homepage, category pages,
// tag pages, and related-posts all read from this collection automatically.
const posts = defineCollection({
  type: 'content',
  schema: z.object({
    title: z.string(),
    excerpt: z.string(),
    category: z.string(),
    tags: z.array(z.string()).default([]),
    author: z.string().default('Alpha Ledger'),
    date: z.coerce.date(),
    updatedDate: z.coerce.date().optional(),
    image: z.string(),
    imageAlt: z.string().optional(),
    featured: z.boolean().default(false),
    trending: z.boolean().default(false),
  }),
});

export const collections = { posts };
