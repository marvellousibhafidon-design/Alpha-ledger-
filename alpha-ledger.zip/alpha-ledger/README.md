# Alpha Ledger

Technology & finance publishing site. Static, built with Astro + Tailwind,
deployed on Netlify. No database — every article is a Markdown file with
front matter in `src/content/posts/`. Add a file there and the homepage,
its category page, its tag pages, and related-articles all update on the
next build automatically. Nothing else needs to be touched.

## Status

- [x] Astro + Tailwind scaffolded, design tokens ported from the spec
- [x] Base layout, logo, header (sticky/scroll-aware, theme toggle), footer
- [x] Reusable `ArticleCard` component (featured / default / compact variants)
- [x] Content Engine: Astro content collection (`src/content/config.ts`)
      with a validated schema (title, excerpt, category, tags, author,
      date, image, featured, trending)
- [x] Article page template (`src/pages/posts/[...slug].astro`) — breadcrumbs,
      category badge, metadata, table of contents (auto-generated from
      headings), tags, author box, prev/next, related articles
      (ranked by shared tags → same category → newest)
- [x] Category pages (`/category/<name>`) and tag pages (`/tag/<name>`) —
      both auto-generated from whatever categories/tags actually exist in content
- [x] Homepage: magazine hero, trending ticker, latest grid, category
      blocks — all reading from real content, not sample data
- [x] Reading time computed automatically (words ÷ 220), never entered manually
- [ ] Search (Pagefind)
- [ ] SEO engine (sitemap, RSS, JSON-LD, canonical tags)
- [ ] FAQ section on article pages (add once you're supplying FAQ content per article)

## Adding a new article

Drop a new `.md` file in `src/content/posts/` with front matter like the
existing one, rebuild, redeploy. That's the whole workflow — no other file
needs editing.

## Run locally

```
npm install
npm run dev       # http://localhost:4321
npm run build     # outputs to /dist
```

## Deploy to Netlify

1. Push this folder to a GitHub repo (or drag-and-drop the folder into
   Netlify's "Deploy manually" upload).
2. Build command: `npm run build` · Publish directory: `dist`
   (already set in `netlify.toml`, so Netlify should pick it up automatically).

## What's real vs. placeholder right now

- The **design system, header, footer, and card components are real** —
  what you'll see reflects the final visual language.
- The **articles are sample data**, not a working publishing pipeline yet.
  Category pages, the search bar, and individual article pages (`/posts/...`)
  aren't built yet — clicking through will 404. That's next.

## Structure

```
src/
  layouts/Layout.astro   → page shell (head, header, footer)
  components/            → Logo, Header, Footer, ArticleCard, Newsletter
  pages/index.astro      → homepage
  data/posts.sample.json → placeholder content
  styles/global.css      → CSS variable tokens + Tailwind layers
```
