/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,ts,tsx,md,mdx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // Dark theme (default) — see src/styles/global.css for the
        // light-theme CSS variable overrides these map to.
        bg: 'var(--color-bg)',
        surface: 'var(--color-surface)',
        'surface-alt': 'var(--color-surface-alt)',

        'text-primary': 'var(--color-text-primary)',
        'text-secondary': 'var(--color-text-secondary)',
        'text-muted': 'var(--color-text-muted)',

        primary: {
          DEFAULT: '#2563EB',
          hover: '#3B74F0',
        },
        secondary: '#10B981', // finance gains / success
        accent: '#F59E0B',    // trending / featured
        danger: '#EF4444',

        border: 'var(--color-border)',
      },
      fontFamily: {
        heading: ['"Space Grotesk"', '"Manrope"', '"Inter"', '"Noto Sans"', 'sans-serif'],
        body: ['"Inter"', '"Manrope"', '"Noto Sans"', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'monospace'],
      },
      fontSize: {
        h1: ['clamp(1.875rem, 2vw + 1.5rem, 3rem)', { lineHeight: '1.15' }],
        h2: ['clamp(1.5rem, 1.4vw + 1.2rem, 2.25rem)', { lineHeight: '1.15' }],
        h3: ['1.75rem', { lineHeight: '1.2' }],
        h4: ['1.375rem', { lineHeight: '1.25' }],
      },
      borderRadius: {
        button: '12px',
        card: '18px',
        image: '16px',
        input: '10px',
        badge: '999px',
      },
      boxShadow: {
        light: '0 1px 3px rgba(0, 0, 0, 0.24)',
        medium: '0 4px 16px rgba(0, 0, 0, 0.32)',
        heavy: '0 12px 32px rgba(0, 0, 0, 0.4)',
      },
      transitionDuration: {
        fast: '150ms',
        normal: '200ms',
        slow: '300ms',
      },
      maxWidth: {
        content: '760px',
        page: '1280px',
      },
      spacing: {
        header: '70px',
      },
    },
  },
  plugins: [],
};
