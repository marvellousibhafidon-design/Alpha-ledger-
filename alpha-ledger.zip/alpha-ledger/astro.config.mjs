import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';

// https://astro.build/config
export default defineConfig({
  site: 'https://alphaledger.netlify.app',
  integrations: [
    tailwind({
      applyBaseStyles: false, // we load our own reset + base layer from src/styles/global.css
    }),
  ],
});
